package com.javatechie.k8s;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootK8sDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
