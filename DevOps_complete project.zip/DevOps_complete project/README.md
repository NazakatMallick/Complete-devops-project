# springboot-k8s-example
Deploy your spring boot application to kubernetes cluster 
